package com.sky.maskpage.api;

import android.view.View;

public interface OnMackListener {
    void OnClick(View v, int position);

    void onFinish();
}
